from Classes.Logic.LogicCommandManager import LogicCommandManager
from Classes.Packets.PiranhaMessage import PiranhaMessage
import json
from Classes.Messaging import Messaging

from Classes.Packets.PiranhaMessage import PiranhaMessage
from Database.DatabaseHandler import DatabaseHandler
from Classes.Commands.LogicServerCommand import LogicServerCommand

from Classes.Messaging import Messaging

from Database.DatabaseHandler import DatabaseHandler

class SetSupportedCreatorResponseMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields):
        self.writeVInt(1)
        self.writeString(fields["Code"])

    def decode(self):
        return {}

    def execute(message, calling_instance, fields, cryptoInit):
        fields["Socket"] = calling_instance.client

        Messaging.sendMessage(24104, cryptoInit, calling_instance.player)
        db_instance.updatePlayerData(player_data, calling_instance)

    def getMessageType(self):
        return 28686

    def getMessageVersion(self):
        return self.messageVersion