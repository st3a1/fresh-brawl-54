from Classes.Messaging import Messaging

from Classes.Packets.PiranhaMessage import PiranhaMessage
import time

class TeamSetMemberReadyMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields):
        pass

    def decode(self):
        fields = {}
        return fields

    def execute(message, calling_instance, fields, cryptoInit):
        fields["tick"] = 155
        fields["Socket"] = calling_instance.client
        Messaging.sendMessage(24112, fields, cryptoInit, calling_instance.player)
        Messaging.sendMessage(20559, fields, cryptoInit, calling_instance.player)
        Messaging.sendMessage(24112, fields, cryptoInit, calling_instance.player)
        
        tickMax = 200
        while fields["tick"] != tickMax:
        	fields["tick"] += 1
        	Messaging.sendMessage(24109, fields, cryptoInit, calling_instance.player)
        	time.sleep(0.045)       	
        if fields["tick"] == 200:
        	Messaging.sendMessage(23456, fields, cryptoInit, calling_instance.player)

    def getMessageType(self):
        return 14700

    def getMessageVersion(self):
        return self.messageVersion
