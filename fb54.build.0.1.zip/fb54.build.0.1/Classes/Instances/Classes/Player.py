import json
import random
import string

from datetime import date
today = date.today()

daily_freebie_items = [45, 1, 41, 38]

daily_freebie_item_chance = random.randint(1, 60000)

jackpot_values = [200, 300, 500, 700, 600, 650, 620, 250, 350, 450, 470]



if daily_freebie_item_chance >= 40000:
	jackpot_state = 1
	random_cumulative = random.randint(10, 50)
else:
	jackpot_state = 2
	random_cumulative = random.choice(jackpot_values)

random_generic_offer = random.randint(1, 50000000)

random_slot_offers = [
{"Item": 41, "Title": 'АКЦИЯ К ПОВЫШЕНИЮ УРОВНЯ', "Cost": 29, "BGR": 'offer_starter_pack', "Amount": 1000, "OldCost": 0, "Claimed": False, "BundleID": f"Offer_Generic_{random_generic_offer}"},

{"Item": 1, "Title": 'АКЦИЯ К ПОВЫШЕНИЮ УРОВНЯ', "Cost": 29, "BGR": 'offer_starter_pack', "Amount": 1000, "OldCost": 0, "Claimed": False, "BundleID": f"Offer_Generic_{random_generic_offer}"},

{"Item": 38, "Title": 'ОСОБАЯ АКЦИЯ', "Cost": 29, "BGR": 'offer_starter_pack', "Amount": 1000, "OldCost": 0, "Claimed": False, "BundleID": f"Offer_Generic_{random_generic_offer}"},

{"Item": 1, "Title": 'ОСОБАЯ АКЦИЯ', "Cost": 29, "BGR": 'offer_starter_pack', "Amount": 1000, "OldCost": 0, "Claimed": True, "BundleID": f"Offer_Generic_{random_generic_offer}"},

{"Item": 1, "Title": 'ОСОБАЯ АКЦИЯ', "Cost": 29, "BGR": 'offer_starter_pack', "Amount": 1000, "OldCost": 0, "Claimed": True, "BundleID": f"Offer_Generic_{random_generic_offer}"},

{"Item": 1, "Title": 'ОСОБАЯ АКЦИЯ', "Cost": 29, "BGR": 'offer_starter_pack', "Amount": 1000, "OldCost": 0, "Claimed": True, "BundleID": f"Offer_Generic_{random_generic_offer}"},

{"Item": 1, "Title": 'ОСОБАЯ АКЦИЯ', "Cost": 29, "BGR": 'offer_starter_pack', "Amount": 1000, "OldCost": 0, "Claimed": True, "BundleID": f"Offer_Generic_{random_generic_offer}"},

{"Item": 38, "Title": 'ОСОБАЯ АКЦИЯ', "Cost": 49, "BGR": 'offer_starter_pack', "Amount": 250, "OldCost": 0, "Claimed": False, "BundleID": f"Offer_Generic_{random_generic_offer}"},

{"Item": 38, "Title": 'ОСОБАЯ АКЦИЯ', "Cost": 79, "BGR": 'offer_starter_pack', "Amount": 500, "OldCost": 0, "Claimed": False, "BundleID": f"Offer_Generic_{random_generic_offer}"},

{"Item": 38, "Title": 'ОСОБАЯ АКЦИЯ', "Cost": 79, "BGR": 'offer_starter_pack', "Amount": 500, "OldCost": 0, "Claimed": False, "BundleID": f"Offer_Generic_{random_generic_offer}"},

{"Item": 38, "Title": 'ОСОБАЯ АКЦИЯ', "Cost": 99, "BGR": 'offer_starter_pack', "Amount": 1000, "OldCost": 0, "Claimed": False, "BundleID": f"Offer_Generic_{random_generic_offer}"}

]


class Player:
    ClientVersion = "0.0.0"

    ID = [0, 1]
    Token = ""
    Name = "Brawler"
    Registered = False
    Thumbnail = 0
    Namecolor = 0
    Region = "CA"
    ContentCreator = "BSDS"

    Coins = 99999
    Gems = 99999
    StarPoints = 0
    Trophies = 99999
    HighestTrophies = 99999
    TrophyRoadTier = 1
    Experience = 0
    Level = 500
    Tokens = 99999
    TokensDoubler = 1000
    Bling = 99999
    ChromaticCoins = 99999
    RecruitTokens = 0
    PowerPoints = 99999
    ClubCoins = 99999
    Resources = {"Coins": 99999, "Gems": 99999, "StarPoints": 0, "Tokens": 0, "TokensDoubler": 0, "Bling": 99999, "RecruitTokens": 0, "ChromaticCoins": 99999, "ClubCoins": 99999}
    Victories = {"Solo": 0, "3v3": 0}

    SelectedSkin = 0
    SelectedBrawler = 0
    RandomizerSelectedSkins = []
    OwnedPins = []
    OwnedThumbnails = []
    OwnedSkins = []
    OwnedBrawlers = {
        0: {'CardID': 0, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'MasteryPoints': 0, 'MasteryTier': 0},
    }
    OwnedTitles = []
    OwnedAccessories = []
    
    # Basic Shop
    GatchaItems = {}
    PurchasedOffers = []
    
    # Brawl Pass
    Pass32Int = 0
    Pass64Int = 0
    Pass96Int = 0
    
    Pass32IntP = 0
    Pass64IntP = 0
    Pass96IntP = 0
    
    
    BrawlPassActive = False
    
    # Road Data
    RoadType = 0
    PassLevel = 0
    PassSeason = 0
    
    # Starr Road    
    RecruitBrawler = 8
    FameAvailable = False
    
    # Profile 
    BattleIcon1 = 0
    BattleIcon2 = 0
    BattleEmote = 0
    Title = 0
    
    BattleIcon1Visible = False
    BattleIcon2Visible = False
    BattleEmoteVisible = False
    TitleVisible = False
    
    FavouriteBrawler = 0
    
    
    Brawlers = [1, 2, 3, 10, 13, 24, 4, 7, 9, 18, 19, 22, 25, 27, 34, 61, 30, 45, 15, 16, 20, 29, 36, 43, 50, 17, 21, 32, 31, 42, 64, 71, 73, 5, 12, 23, 28, 40, 52, 63]
    
    # Starr Drops   
    DropRarity = None
    DropAmount = 0
    DailyWins = 0
    
    # Notifications
    
    # SeenNotifications - scrapped feature
    SeenNotifications = []
    
    Notifications = [{"Type": 64, "Readed": False,"Timer": 99999, "Text": "BRAWL PASS DONATION", "RewardType": 16, "Amount": 170, "Number": 0, "ItemName": "Gems", "Extra": 0, "Brawler": 0, "BrawlerCard": 0, "BrawlerPower": 1, "StarrDrops": False}]
    
    Quests = [{"MissionType": 1, "AchievedGoal": 1, "QuestGoal": 5000, "GameMode": 3, "Brawler": 0, "QuestReward": 1, "Amount": 500, "CurrentLevel": 0, "MaxLevel": 0, "Time": 99999, "NeedsPass": False, "Complete": False, "Number": 0}]
    
    # Daily Login Calendar
    ClaimedLoginRewardIndex = -1
    LoginRewardIndex = 0
    
    # Login Date
    LoginDay = int(today.strftime("%-d"))
    LoginMonth = int(today.strftime("%-m"))
    LoginYear = int(today.strftime("%Y"))
    
    # Daily Freebie
    DailyFreebieItem = random.choice(daily_freebie_items)
    DailyFreebieItemAmount = random_cumulative
    DailyFreebieClaimed = False
    Jackpot = jackpot_state
    
    # Random Offer Generation
    
    OfferSlot1 = [random.choice(random_slot_offers)]
    
    OfferSlot2 = [random.choice(random_slot_offers)]
    
    OfferSlot3 = [random.choice(random_slot_offers)]
    
    
    

    def __init__(self):
        pass

    def getDataTemplate(self, highid, lowid, token):
        if highid == 0 or lowid == 0:
            self.ID[0] = int(''.join([str(random.randint(0, 9)) for _ in range(1)]))
            self.ID[1] = int(''.join([str(random.randint(0, 9)) for _ in range(8)]))
            self.Token = ''.join(random.choice(string.ascii_letters + string.digits) for i in range(40))
        else:
            self.ID[0] = highid
            self.ID[1] = lowid
            self.Token = token

        DBData = {
            'ID': self.ID,
            'Token': self.Token,
            'Name': self.Name,
            'Registered': self.Registered,
            'Thumbnail': self.Thumbnail,
            'Namecolor': self.Namecolor,
            'Region': self.Region,
            'ContentCreator': self.ContentCreator,
            'Coins': self.Coins,
            'Gems': self.Gems,
            'StarPoints': self.StarPoints,
            'Trophies': self.Trophies,
            'HighestTrophies': self.HighestTrophies,
            'TrophyRoadTier': self.TrophyRoadTier,
            'Experience': self.Experience,
            'Level': self.Level,
            'Tokens': self.Tokens,
            'TokensDoubler': self.TokensDoubler,
            'SelectedBrawler': self.SelectedBrawler,
            'SelectedSkin': self.SelectedSkin,
            'OwnedPins': self.OwnedPins,
            'OwnedThumbnails': self.OwnedThumbnails,
            'OwnedBrawlers': self.OwnedBrawlers,
            'OwnedSkins': self.OwnedSkins,
            'OwnedTitles': self.OwnedTitles,
            'OwnedAccessories': self.OwnedAccessories,
            'Bling': self.Bling,
            'ChromaticCoins': self.ChromaticCoins,
            'RecruitTokens': self.RecruitTokens,
            'PowerPoints': self.PowerPoints,
            'ClubCoins': self.ClubCoins,
            'GatchaItems': self.GatchaItems,
            'PurchasedOffers': self.PurchasedOffers,
            'Pass32Int': self.Pass32Int,
            'Pass64Int': self.Pass64Int,
            'Pass96Int': self.Pass96Int,
            'Pass32IntP': self.Pass32IntP,
            'Pass64IntP': self.Pass64IntP,
            'Pass96IntP': self.Pass96IntP,
            'BrawlPassActive': self.BrawlPassActive,
            'RoadType': self.RoadType,
            'PassLevel': self.PassLevel,
            'PassSeason': self.PassSeason,
            'RecruitBrawler': self.RecruitBrawler,
            'FameAvailable': self.FameAvailable,
            'Brawlers': self.Brawlers,
            'BattleIcon1': self.BattleIcon1,
            'BattleIcon2': self.BattleIcon2,
            'BattleEmote': self.BattleEmote,
            'Title': self.Title,
            'BattleIcon1Visible': self.BattleIcon1Visible,
            'BattleIcon2Visible': self.BattleIcon2Visible,
            'BattleEmoteVisible': self.BattleEmoteVisible,
            'TitleVisible': self.TitleVisible,
            'FavouriteBrawler': self.FavouriteBrawler,
            'DropRarity': self.DropRarity,
            'DropAmount': self.DropAmount,
            'SeenNotifications': self.SeenNotifications,
            'Notifications': self.Notifications,
            'Quests': self.Quests,
            'ClaimedLoginRewardIndex': self.ClaimedLoginRewardIndex,
            'LoginRewardIndex': self.LoginRewardIndex,
            'DailyWins': self.DailyWins,
            'LoginDay': self.LoginDay,
            'LoginMonth': self.LoginMonth,
            'LoginYear': self.LoginYear,
            'DailyFreebieItem': self.DailyFreebieItem,
            'DailyFreebieItemAmount': self.DailyFreebieItemAmount,
            'DailyFreebieClaimed': self.DailyFreebieClaimed,
            'OfferSlot1': self.OfferSlot1,
            'OfferSlot2': self.OfferSlot2,
            'OfferSlot3': self.OfferSlot3,
            'Jackpot': self.Jackpot
            
        }
        return DBData

    def toJSON(self):
        return json.loads(json.dumps(self, default=lambda o: o.__dict__,
            sort_keys=True, indent=4))