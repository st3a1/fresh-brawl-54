import json
import random
from Classes.Commands.LogicServerCommand import LogicServerCommand
from Classes.Messaging import Messaging
from Database.DatabaseHandler import DatabaseHandler


class LogicSetSupportedCreatorCommand(LogicServerCommand):
    def __init__(self, commandData):
        super().__init__(commandData)

    def encode(self, fields):
        creator = fields["SupportedCreator"]
        self.writeVInt(1) # Bool
        self.writeString(creator) # str ахаххвв а нахуя я расписал 🦽
        LogicServerCommand.encode(self, fields)
        return self.messagePayload

    def getCommandType(self): # мымо
        return 215