import json
import random
from Classes.Commands.LogicServerCommand import LogicServerCommand
from Classes.Messaging import Messaging
from Database.DatabaseHandler import DatabaseHandler


class LogicGemsAdded(LogicServerCommand):
    def __init__(self, commandData):
        super().__init__(commandData)

    def encode(self, fields):
        gems = fields["Gems"]
        self.writeVInt(0); #// sound можно было и в бул но лень
        self.writeInt(gems);# // count 
        self.writeInt(0);
        self.writeInt(0);
        self.writeString("");
        LogicServerCommand.encode(self, fields)
        return self.messagePayload

    def getCommandType(self): # мымо
        return 202